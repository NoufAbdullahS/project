This folder stores uploaded images.
